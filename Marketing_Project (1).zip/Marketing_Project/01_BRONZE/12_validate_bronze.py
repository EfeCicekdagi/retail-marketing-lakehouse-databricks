# Databricks notebook source
# MAGIC %md
# MAGIC # 12_validate_bronze — Working Version
# MAGIC
# MAGIC Bu notebook seçilen batch için Bronze kalite kontrollerini çalıştırır ve
# MAGIC `retail_marketing.audit.data_quality_log` tablosuna yazar.
# MAGIC
# MAGIC Parametreler:
# MAGIC - `BatchID`
# MAGIC - `ProcessDay`
# MAGIC - `ProcessWeek`
# MAGIC
# MAGIC Aynı batch tekrar doğrulanırsa eski Bronze DQ kayıtları silinir ve yeniden üretilir.
# MAGIC

# COMMAND ----------

required_parameters = [
    "BatchID",
    "LoadMode",
    "ProcessDate",
    "ProcessDay",
    "ProcessWeek"
]

parameters = {}

for name in required_parameters:
    try:
        value = dbutils.widgets.get(name).strip()
    except Exception as exc:
        raise ValueError(
            f"{name} parametresi notebooka gelmedi."
        ) from exc

    if not value:
        raise ValueError(
            f"{name} parametresi boş geldi."
        )

    parameters[name] = value

print("Gelen parametreler:")
for key, value in parameters.items():
    print(f"{key} = {value!r}")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE WIDGET TEXT ProcessWeek DEFAULT "1";

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG retail_marketing
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     TRIM(:BatchID) AS BatchID,
# MAGIC     CAST(:ProcessDay AS DECIMAL(10,0)) AS ProcessDay,
# MAGIC     CAST(:ProcessWeek AS DECIMAL(10,0)) AS ProcessWeek
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Batch'in varlığını ve durumunu kontrol et
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     BatchID,
# MAGIC     ProcessDate,
# MAGIC     ProcessDay,
# MAGIC     ProcessWeek,
# MAGIC     LoadMode,
# MAGIC     BatchStatus,
# MAGIC     StartTime,
# MAGIC     EndTime
# MAGIC FROM retail_marketing.control.etl_batch_control
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Aynı batch'e ait eski Bronze kalite loglarını temizle
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Bütün Bronze kontrollerini tek kaynak view içinde hazırla
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW bronze_dq_results AS
# MAGIC
# MAGIC -- 1) Batch RUNNING olmalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_BATCH_RUNNING') AS DQLogID,
# MAGIC     TRIM(:BatchID) AS BatchID,
# MAGIC     'BRONZE' AS LayerName,
# MAGIC     'retail_marketing.control.etl_batch_control' AS TableName,
# MAGIC     'batch_is_running' AS CheckName,
# MAGIC     'BUSINESS_RULE' AS CheckCategory,
# MAGIC     'CRITICAL' AS SeverityLevel,
# MAGIC     CAST(1 AS DECIMAL(20,0)) AS CheckedRowCount,
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ) AS PassedRowCount,
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 1 THEN 0 ELSE 1 END
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ) AS FailedRowCount,
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 1 THEN 0 ELSE 1 END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ) AS FailureRate,
# MAGIC     CASE WHEN COUNT(*) = 1 THEN 'PASS' ELSE 'FAIL' END AS CheckStatus,
# MAGIC     'Bronze doğrulaması için batch RUNNING durumda olmalıdır.' AS CheckDescription
# MAGIC FROM retail_marketing.control.etl_batch_control
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND BatchStatus = 'RUNNING'
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 2) Transaction batch boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_TRANSACTION_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID),
# MAGIC     'BRONZE',
# MAGIC     'retail_marketing.bronze.transaction_data_raw',
# MAGIC     'transaction_batch_not_empty',
# MAGIC     'RECONCILIATION',
# MAGIC     'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için transaction Bronze kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.bronze.transaction_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 3) Transaction DAY kontrolü
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_TRANSACTION_PROCESS_DAY'),
# MAGIC     TRIM(:BatchID),
# MAGIC     'BRONZE',
# MAGIC     'retail_marketing.bronze.transaction_data_raw',
# MAGIC     'transaction_process_day_check',
# MAGIC     'BUSINESS_RULE',
# MAGIC     'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 0
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN day_no IS NULL
# MAGIC                   OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC                 THEN 1 ELSE 0 END), 0) / COUNT(*)
# MAGIC         END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     CONCAT(
# MAGIC         'Transaction DAY değeri ProcessDay=',
# MAGIC         CAST(:ProcessDay AS STRING),
# MAGIC         ' ile aynı olmalıdır.'
# MAGIC     )
# MAGIC FROM retail_marketing.bronze.transaction_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 4) Transaction zorunlu alanlar
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_TRANSACTION_REQUIRED_FIELDS'),
# MAGIC     TRIM(:BatchID),
# MAGIC     'BRONZE',
# MAGIC     'retail_marketing.bronze.transaction_data_raw',
# MAGIC     'transaction_required_fields',
# MAGIC     'NOT_NULL',
# MAGIC     'WARNING',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 0
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN basket_id IS NULL
# MAGIC                   OR product_id IS NULL
# MAGIC                   OR day_no IS NULL
# MAGIC                 THEN 1 ELSE 0 END), 0) / COUNT(*)
# MAGIC         END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'WARN'
# MAGIC     END,
# MAGIC     'basket_id, product_id ve day_no alanları null olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.transaction_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 5) Transaction teknik metadata
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_TRANSACTION_METADATA'),
# MAGIC     TRIM(:BatchID),
# MAGIC     'BRONZE',
# MAGIC     'retail_marketing.bronze.transaction_data_raw',
# MAGIC     'transaction_metadata_not_null',
# MAGIC     'NOT_NULL',
# MAGIC     'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN BatchID IS NULL
# MAGIC               OR ProcessDate IS NULL
# MAGIC               OR ETLTime IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC               OR SourceFile IS NULL
# MAGIC               OR SourceSystem IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN BatchID IS NULL
# MAGIC               OR ProcessDate IS NULL
# MAGIC               OR ETLTime IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC               OR SourceFile IS NULL
# MAGIC               OR SourceSystem IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 0
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN BatchID IS NULL
# MAGIC                   OR ProcessDate IS NULL
# MAGIC                   OR ETLTime IS NULL
# MAGIC                   OR RecordHash IS NULL
# MAGIC                   OR SourceFile IS NULL
# MAGIC                   OR SourceSystem IS NULL
# MAGIC                 THEN 1 ELSE 0 END), 0) / COUNT(*)
# MAGIC         END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN BatchID IS NULL
# MAGIC               OR ProcessDate IS NULL
# MAGIC               OR ETLTime IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC               OR SourceFile IS NULL
# MAGIC               OR SourceSystem IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Transaction teknik metadata alanları dolu olmalıdır.'
# MAGIC FROM retail_marketing.bronze.transaction_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 6) Coupon redemption DAY kontrolü; 0 kayıt geçerlidir
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_COUPON_PROCESS_DAY'),
# MAGIC     TRIM(:BatchID),
# MAGIC     'BRONZE',
# MAGIC     'retail_marketing.bronze.coupon_redemption_raw',
# MAGIC     'coupon_redemption_process_day',
# MAGIC     'BUSINESS_RULE',
# MAGIC     'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 0
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN day_no IS NULL
# MAGIC                   OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC                 THEN 1 ELSE 0 END), 0) / COUNT(*)
# MAGIC         END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL
# MAGIC               OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     CONCAT(
# MAGIC         'Coupon redemption DAY değeri ProcessDay=',
# MAGIC         CAST(:ProcessDay AS STRING),
# MAGIC         ' ile aynı olmalıdır.'
# MAGIC     )
# MAGIC FROM retail_marketing.bronze.coupon_redemption_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 7-12) Altı master kaynak ilgili batch için dolu olmalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_PRODUCT_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.product_raw',
# MAGIC     'product_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Product kaynağı ilgili batch için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.product_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_HOUSEHOLD_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.household_demographic_raw',
# MAGIC     'household_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Household kaynağı ilgili batch için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.household_demographic_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_CAMPAIGN_DESC_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.campaign_desc_raw',
# MAGIC     'campaign_desc_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Campaign description kaynağı ilgili batch için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_CAMPAIGN_TARGET_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.campaign_target_raw',
# MAGIC     'campaign_target_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Campaign target kaynağı ilgili batch için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.campaign_target_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_COUPON_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.coupon_raw',
# MAGIC     'coupon_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Coupon kaynağı ilgili batch için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.coupon_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_CAUSAL_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.causal_data_raw',
# MAGIC     'causal_batch_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Causal data ilgili batch ve hafta için boş olmamalıdır.'
# MAGIC FROM retail_marketing.bronze.causal_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 13) Product natural key null
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_PRODUCT_ID_NOT_NULL'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.product_raw',
# MAGIC     'product_id_not_null',
# MAGIC     'NOT_NULL', 'WARNING',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Product natural key null kontrolü.'
# MAGIC FROM retail_marketing.bronze.product_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 14) Household natural key null
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_HOUSEHOLD_KEY_NOT_NULL'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.household_demographic_raw',
# MAGIC     'household_key_not_null',
# MAGIC     'NOT_NULL', 'WARNING',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN household_key IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN household_key IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN household_key IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN household_key IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Household natural key null kontrolü.'
# MAGIC FROM retail_marketing.bronze.household_demographic_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 15) Campaign natural key null
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_CAMPAIGN_ID_NOT_NULL'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.campaign_desc_raw',
# MAGIC     'campaign_id_not_null',
# MAGIC     'NOT_NULL', 'WARNING',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN campaign_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN campaign_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN campaign_id IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN campaign_id IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Campaign natural key null kontrolü.'
# MAGIC FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 16) Duplicate product key sayısı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_DUPLICATE_PRODUCT_ID'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.product_raw',
# MAGIC     'duplicate_product_id',
# MAGIC     'UNIQUENESS', 'WARNING',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.bronze.product_raw WHERE BatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Bronze duplicate product_id grupları gözlemlenir; temizleme Silver katmanında yapılır.'
# MAGIC FROM (
# MAGIC     SELECT product_id
# MAGIC     FROM retail_marketing.bronze.product_raw
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND product_id IS NOT NULL
# MAGIC     GROUP BY product_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 17) Duplicate household key sayısı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_DUPLICATE_HOUSEHOLD_KEY'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.household_demographic_raw',
# MAGIC     'duplicate_household_key',
# MAGIC     'UNIQUENESS', 'WARNING',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.bronze.household_demographic_raw WHERE BatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Bronze duplicate household_key grupları gözlemlenir; temizleme Silver katmanında yapılır.'
# MAGIC FROM (
# MAGIC     SELECT household_key
# MAGIC     FROM retail_marketing.bronze.household_demographic_raw
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND household_key IS NOT NULL
# MAGIC     GROUP BY household_key
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 18) Duplicate campaign key sayısı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_DUPLICATE_CAMPAIGN_ID'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.bronze.campaign_desc_raw',
# MAGIC     'duplicate_campaign_id',
# MAGIC     'UNIQUENESS', 'WARNING',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.bronze.campaign_desc_raw WHERE BatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'WARN' END,
# MAGIC     'Bronze duplicate campaign_id grupları gözlemlenir; temizleme Silver katmanında yapılır.'
# MAGIC FROM (
# MAGIC     SELECT campaign_id
# MAGIC     FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND campaign_id IS NOT NULL
# MAGIC     GROUP BY campaign_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 19) Bronze ETL log durumları
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_BRONZE_LOAD_STATUS'),
# MAGIC     TRIM(:BatchID), 'BRONZE',
# MAGIC     'retail_marketing.audit.etl_table_load_log',
# MAGIC     'bronze_load_status_check',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 1
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC                 THEN 0 ELSE 1 END), 0)
# MAGIC         END
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE
# MAGIC             WHEN COUNT(*) = 0 THEN 1
# MAGIC             ELSE COALESCE(SUM(CASE
# MAGIC                 WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC                 THEN 0 ELSE 1 END), 0) / COUNT(*)
# MAGIC         END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COUNT(*) = 0 THEN 'FAIL'
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0) = 0
# MAGIC         THEN 'PASS'
# MAGIC         ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Bronze yükleme logları SUCCESS, SUCCESS_WITH_WARNING veya SKIPPED olmalıdır.'
# MAGIC FROM retail_marketing.audit.etl_table_load_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Kalite sonuçlarını audit tablosuna yaz
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.audit.data_quality_log (
# MAGIC     DQLogID,
# MAGIC     BatchID,
# MAGIC     LayerName,
# MAGIC     TableName,
# MAGIC     CheckName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription,
# MAGIC     ETLTime
# MAGIC )
# MAGIC SELECT
# MAGIC     DQLogID,
# MAGIC     BatchID,
# MAGIC     LayerName,
# MAGIC     TableName,
# MAGIC     CheckName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription,
# MAGIC     current_timestamp()
# MAGIC FROM bronze_dq_results
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Detaylı kalite sonuçları
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     CheckName,
# MAGIC     TableName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC ORDER BY
# MAGIC     CASE CheckStatus
# MAGIC         WHEN 'FAIL' THEN 1
# MAGIC         WHEN 'WARN' THEN 2
# MAGIC         WHEN 'PASS' THEN 3
# MAGIC         ELSE 4
# MAGIC     END,
# MAGIC     TableName,
# MAGIC     CheckName
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Özet
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     CheckStatus,
# MAGIC     COUNT(*) AS CheckCount
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC GROUP BY CheckStatus
# MAGIC ORDER BY CheckStatus
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     COUNT(*) AS CriticalFailureCount
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC   AND CheckStatus = 'FAIL'
# MAGIC   AND SeverityLevel IN ('ERROR', 'CRITICAL')
# MAGIC