# Databricks notebook source
# MAGIC %md
# MAGIC # 11_load_bronze_master_data
# MAGIC
# MAGIC Bu notebook 6 master/ilişki kaynağını Bronze katmanına yükler.
# MAGIC
# MAGIC - product.csv
# MAGIC - hh_demographic.csv
# MAGIC - campaign_desc.csv
# MAGIC - campaign_table.csv
# MAGIC - coupon.csv
# MAGIC - causal_data.csv
# MAGIC
# MAGIC Notebook aynı `BatchID` ile tekrar çalıştırılabilir. İlgili batch kayıtlarını önce temizleyip yeniden yükler.
# MAGIC

# COMMAND ----------

required_parameters = [
    "BatchID",
    "LoadMode",
    "ProcessDate",
    "ProcessDay",
    "ProcessWeek"
]

parameters = {}

for name in required_parameters:
    try:
        value = dbutils.widgets.get(name).strip()
    except Exception as exc:
        raise ValueError(
            f"{name} parametresi notebooka gelmedi."
        ) from exc

    if not value:
        raise ValueError(
            f"{name} parametresi boş geldi."
        )

    parameters[name] = value

print("Gelen parametreler:")
for key, value in parameters.items():
    print(f"{key} = {value!r}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     CAST(:ProcessWeek AS DECIMAL(10,0)) AS ProcessWeek,
# MAGIC     UPPER(:LoadMode) AS LoadMode;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC LIST '/Volumes/retail_marketing/source/source_files/master/';
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.control.etl_batch_control AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         CAST(NULL AS DECIMAL(10,0)) AS ProcessDay,
# MAGIC         CAST(:ProcessWeek AS DECIMAL(10,0)) AS ProcessWeek,
# MAGIC         UPPER(:LoadMode) AS LoadMode
# MAGIC ) AS source
# MAGIC ON target.BatchID = source.BatchID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.ProcessDate = source.ProcessDate,
# MAGIC     target.ProcessWeek = source.ProcessWeek,
# MAGIC     target.LoadMode = source.LoadMode,
# MAGIC     target.BatchStatus = 'RUNNING',
# MAGIC     target.EndTime = NULL,
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     BatchID, ProcessDate, ProcessDay, ProcessWeek, LoadMode,
# MAGIC     BatchStatus, StartTime, EndTime, TriggerType, TriggeredBy,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.BatchID, source.ProcessDate, source.ProcessDay, source.ProcessWeek,
# MAGIC     source.LoadMode, 'RUNNING', current_timestamp(), NULL,
# MAGIC     'MANUAL', current_user(), NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Product
# MAGIC

# COMMAND ----------

volume_path = "/Volumes/retail_marketing/source/source_files"


def list_files_recursive(path):
    for item in dbutils.fs.ls(path):
        if item.isDir():
            list_files_recursive(item.path)
        else:
            print(item.path)

list_files_recursive(volume_path)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/campaign_desc.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW product_source AS
# MAGIC SELECT
# MAGIC     TRY_CAST(PRODUCT_ID AS DECIMAL(10,0)) AS product_id,
# MAGIC     TRY_CAST(MANUFACTURER AS DECIMAL(10,0)) AS manufacturer,
# MAGIC     CAST(DEPARTMENT AS STRING) AS department,
# MAGIC     CAST(BRAND AS STRING) AS brand,
# MAGIC     CAST(COMMODITY_DESC AS STRING) AS commodity_desc,
# MAGIC     CAST(SUB_COMMODITY_DESC AS STRING) AS sub_commodity_desc,
# MAGIC     CAST(CURR_SIZE_OF_PRODUCT AS STRING) AS curr_size_of_product,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/product.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC ;
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM product_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_PRODUCT') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         NULL AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'product',
# MAGIC     'retail_marketing.bronze.product_raw', 'FULL_SNAPSHOT_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.product_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.product_raw (
# MAGIC     product_id, manufacturer, department, brand, commodity_desc, sub_commodity_desc, curr_size_of_product,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     product_id, manufacturer, department, brand, commodity_desc, sub_commodity_desc, curr_size_of_product,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(CAST(product_id AS STRING), '<NULL>'), COALESCE(CAST(manufacturer AS STRING), '<NULL>'), COALESCE(department, '<NULL>'), COALESCE(brand, '<NULL>'), COALESCE(commodity_desc, '<NULL>'), COALESCE(sub_commodity_desc, '<NULL>'), COALESCE(curr_size_of_product, '<NULL>')), 256) AS RecordHash
# MAGIC FROM product_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM product_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.product_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM product_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM product_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.product_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM product_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM product_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.product_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_PRODUCT');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Household demographic
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW household_source AS
# MAGIC SELECT
# MAGIC     CAST(AGE_DESC AS STRING) AS age_desc,
# MAGIC     CAST(MARITAL_STATUS_CODE AS STRING) AS marital_status_code,
# MAGIC     CAST(INCOME_DESC AS STRING) AS income_desc,
# MAGIC     CAST(HOMEOWNER_DESC AS STRING) AS homeowner_desc,
# MAGIC     CAST(HH_COMP_DESC AS STRING) AS hh_comp_desc,
# MAGIC     CAST(HOUSEHOLD_SIZE_DESC AS STRING) AS household_size_desc,
# MAGIC     CAST(KID_CATEGORY_DESC AS STRING) AS kid_category_desc,
# MAGIC     TRY_CAST(household_key AS DECIMAL(10,0)) AS household_key,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/hh_demographic.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC ;
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM household_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_HOUSEHOLD') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         NULL AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'household_demographic',
# MAGIC     'retail_marketing.bronze.household_demographic_raw', 'FULL_SNAPSHOT_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.household_demographic_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.household_demographic_raw (
# MAGIC     age_desc, marital_status_code, income_desc, homeowner_desc, hh_comp_desc, household_size_desc, kid_category_desc, household_key,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     age_desc, marital_status_code, income_desc, homeowner_desc, hh_comp_desc, household_size_desc, kid_category_desc, household_key,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(age_desc, '<NULL>'), COALESCE(marital_status_code, '<NULL>'), COALESCE(income_desc, '<NULL>'), COALESCE(homeowner_desc, '<NULL>'), COALESCE(hh_comp_desc, '<NULL>'), COALESCE(household_size_desc, '<NULL>'), COALESCE(kid_category_desc, '<NULL>'), COALESCE(CAST(household_key AS STRING), '<NULL>')), 256) AS RecordHash
# MAGIC FROM household_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM household_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.household_demographic_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM household_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM household_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.household_demographic_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM household_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM household_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.household_demographic_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_HOUSEHOLD');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Campaign description
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW campaign_desc_source AS
# MAGIC SELECT
# MAGIC     CAST(DESCRIPTION AS STRING) AS description,
# MAGIC     TRY_CAST(CAMPAIGN AS DECIMAL(10,0)) AS campaign_id,
# MAGIC     TRY_CAST(START_DAY AS DECIMAL(10,0)) AS start_day,
# MAGIC     TRY_CAST(END_DAY AS DECIMAL(10,0)) AS end_day,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/campaign_desc.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC ;
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM campaign_desc_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_CAMPAIGN_DESC') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         NULL AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'campaign_desc',
# MAGIC     'retail_marketing.bronze.campaign_desc_raw', 'FULL_SNAPSHOT_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.campaign_desc_raw (
# MAGIC     description, campaign_id, start_day, end_day,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     description, campaign_id, start_day, end_day,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(description, '<NULL>'), COALESCE(CAST(campaign_id AS STRING), '<NULL>'), COALESCE(CAST(start_day AS STRING), '<NULL>'), COALESCE(CAST(end_day AS STRING), '<NULL>')), 256) AS RecordHash
# MAGIC FROM campaign_desc_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM campaign_desc_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_desc_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_desc_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_desc_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_desc_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_CAMPAIGN_DESC');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Campaign target
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW campaign_target_source AS
# MAGIC SELECT
# MAGIC     CAST(DESCRIPTION AS STRING) AS description,
# MAGIC     TRY_CAST(household_key AS DECIMAL(10,0)) AS household_key,
# MAGIC     TRY_CAST(CAMPAIGN AS DECIMAL(10,0)) AS campaign_id,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/campaign_table.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC ;
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM campaign_target_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_CAMPAIGN_TARGET') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         NULL AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'campaign_target',
# MAGIC     'retail_marketing.bronze.campaign_target_raw', 'FULL_SNAPSHOT_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.campaign_target_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.campaign_target_raw (
# MAGIC     description, household_key, campaign_id,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     description, household_key, campaign_id,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(description, '<NULL>'), COALESCE(CAST(household_key AS STRING), '<NULL>'), COALESCE(CAST(campaign_id AS STRING), '<NULL>')), 256) AS RecordHash
# MAGIC FROM campaign_target_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM campaign_target_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.campaign_target_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_target_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_target_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.campaign_target_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_target_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM campaign_target_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.campaign_target_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_CAMPAIGN_TARGET');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Coupon
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW coupon_source AS
# MAGIC SELECT
# MAGIC     TRY_CAST(COUPON_UPC AS DECIMAL(20,0)) AS coupon_upc,
# MAGIC     TRY_CAST(PRODUCT_ID AS DECIMAL(10,0)) AS product_id,
# MAGIC     TRY_CAST(CAMPAIGN AS DECIMAL(10,0)) AS campaign_id,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/coupon.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC ;
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM coupon_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_COUPON') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         NULL AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'coupon',
# MAGIC     'retail_marketing.bronze.coupon_raw', 'FULL_SNAPSHOT_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.coupon_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.coupon_raw (
# MAGIC     coupon_upc, product_id, campaign_id,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     coupon_upc, product_id, campaign_id,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(CAST(coupon_upc AS STRING), '<NULL>'), COALESCE(CAST(product_id AS STRING), '<NULL>'), COALESCE(CAST(campaign_id AS STRING), '<NULL>')), 256) AS RecordHash
# MAGIC FROM coupon_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM coupon_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.coupon_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM coupon_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM coupon_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.coupon_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM coupon_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM coupon_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.coupon_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_COUPON');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Causal weekly
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW causal_source AS
# MAGIC SELECT
# MAGIC     TRY_CAST(PRODUCT_ID AS DECIMAL(10,0)) AS product_id,
# MAGIC     TRY_CAST(STORE_ID AS DECIMAL(10,0)) AS store_id,
# MAGIC     TRY_CAST(WEEK_NO AS DECIMAL(10,0)) AS week_no,
# MAGIC     CAST(display AS STRING) AS display_code,
# MAGIC     CAST(mailer AS STRING) AS mailer_code,
# MAGIC     _metadata.file_path AS SourceFile
# MAGIC FROM read_files(
# MAGIC     '/Volumes/retail_marketing/source/source_files/master/causal_data.csv',
# MAGIC     format => 'csv',
# MAGIC     header => true,
# MAGIC     mode => 'PERMISSIVE'
# MAGIC )
# MAGIC WHERE TRY_CAST(WEEK_NO AS DECIMAL(10,0)) = CAST(:ProcessWeek AS DECIMAL(10,0));
# MAGIC
# MAGIC SELECT COUNT(*) AS SourceRowCount FROM causal_source;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(:BatchID, '_BRONZE_CAUSAL') AS ETLLogID,
# MAGIC         :BatchID AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         CAST(:ProcessWeek AS DECIMAL(20,0)) AS ProcessValue
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = NULL,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName,
# MAGIC     LoadStrategy, ProcessDate, ProcessValue, StartTime, EndTime,
# MAGIC     SourceRowCount, InsertedRowCount, UpdatedRowCount,
# MAGIC     RejectedRowCount, UnchangedRowCount, LoadStatus,
# MAGIC     ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'BRONZE', 'causal_data',
# MAGIC     'retail_marketing.bronze.causal_data_raw', 'INCREMENTAL_WEEK_APPEND',
# MAGIC     source.ProcessDate, source.ProcessValue, current_timestamp(), NULL,
# MAGIC     NULL, 0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.bronze.causal_data_raw
# MAGIC WHERE BatchID = :BatchID;
# MAGIC
# MAGIC INSERT INTO retail_marketing.bronze.causal_data_raw (
# MAGIC     product_id, store_id, week_no, display_code, mailer_code,
# MAGIC     SourceFile, SourceSystem, BatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     product_id, store_id, week_no, display_code, mailer_code,
# MAGIC     SourceFile,
# MAGIC     'DUNNHUMBY_COMPLETE_JOURNEY' AS SourceSystem,
# MAGIC     :BatchID AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     current_timestamp() AS ETLTime,
# MAGIC     SHA2(CONCAT_WS('||', COALESCE(CAST(product_id AS STRING), '<NULL>'), COALESCE(CAST(store_id AS STRING), '<NULL>'), COALESCE(CAST(week_no AS STRING), '<NULL>'), COALESCE(display_code, '<NULL>'), COALESCE(mailer_code, '<NULL>')), 256) AS RecordHash
# MAGIC FROM causal_source
# MAGIC WHERE EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM retail_marketing.control.etl_batch_control b
# MAGIC     WHERE b.BatchID = :BatchID
# MAGIC       AND b.BatchStatus = 'RUNNING'
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     SourceRowCount = (SELECT COUNT(*) FROM causal_source),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*)
# MAGIC         FROM retail_marketing.bronze.causal_data_raw
# MAGIC         WHERE BatchID = :BatchID
# MAGIC     ),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM causal_source) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT COUNT(*) FROM causal_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.causal_data_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN 'SUCCESS'
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT COUNT(*) FROM causal_source) = 0
# MAGIC             THEN 'Kaynak dosya okundu ancak filtre sonucunda 0 kayıt döndü.'
# MAGIC         WHEN (SELECT COUNT(*) FROM causal_source) = (
# MAGIC             SELECT COUNT(*)
# MAGIC             FROM retail_marketing.bronze.causal_data_raw
# MAGIC             WHERE BatchID = :BatchID
# MAGIC         ) THEN NULL
# MAGIC         ELSE 'Kaynak ve Bronze satır sayıları eşleşmiyor.'
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(:BatchID, '_BRONZE_CAUSAL');
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Son kontroller
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 'product' AS SourceName, COUNT(*) AS LoadedRowCount
# MAGIC FROM retail_marketing.bronze.product_raw WHERE BatchID = :BatchID
# MAGIC UNION ALL
# MAGIC SELECT 'household_demographic', COUNT(*)
# MAGIC FROM retail_marketing.bronze.household_demographic_raw WHERE BatchID = :BatchID
# MAGIC UNION ALL
# MAGIC SELECT 'campaign_desc', COUNT(*)
# MAGIC FROM retail_marketing.bronze.campaign_desc_raw WHERE BatchID = :BatchID
# MAGIC UNION ALL
# MAGIC SELECT 'campaign_target', COUNT(*)
# MAGIC FROM retail_marketing.bronze.campaign_target_raw WHERE BatchID = :BatchID
# MAGIC UNION ALL
# MAGIC SELECT 'coupon', COUNT(*)
# MAGIC FROM retail_marketing.bronze.coupon_raw WHERE BatchID = :BatchID
# MAGIC UNION ALL
# MAGIC SELECT 'causal_data', COUNT(*)
# MAGIC FROM retail_marketing.bronze.causal_data_raw WHERE BatchID = :BatchID;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     SourceName,
# MAGIC     TargetTableName,
# MAGIC     LoadStrategy,
# MAGIC     ProcessValue,
# MAGIC     SourceRowCount,
# MAGIC     InsertedRowCount,
# MAGIC     LoadStatus,
# MAGIC     ErrorMessage
# MAGIC FROM retail_marketing.audit.etl_table_load_log
# MAGIC WHERE BatchID = :BatchID
# MAGIC   AND LayerName = 'BRONZE'
# MAGIC   AND SourceName IN (
# MAGIC       'product', 'household_demographic', 'campaign_desc',
# MAGIC       'campaign_target', 'coupon', 'causal_data'
# MAGIC   )
# MAGIC ORDER BY SourceName;
# MAGIC