# Databricks notebook source
# MAGIC %md
# MAGIC # 21_build_silver_master_data — Working Version
# MAGIC
# MAGIC Bu notebook aşağıdaki Bronze tablolarını Silver katmanına taşır:
# MAGIC
# MAGIC - `bronze.product_raw` → `silver.product_clean`
# MAGIC - `bronze.household_demographic_raw` → `silver.household_demographic_clean`
# MAGIC - `bronze.campaign_desc_raw` → `silver.campaign_clean`
# MAGIC - `bronze.campaign_target_raw` → `silver.campaign_target_clean`
# MAGIC - `bronze.coupon_raw` → `silver.coupon_product_clean`
# MAGIC - `bronze.causal_data_raw` → `silver.promotion_weekly_clean`
# MAGIC
# MAGIC Özellikler:
# MAGIC - Aynı `BatchID` tekrar çalıştırılabilir.
# MAGIC - Natural key bazında duplicate temizlenir.
# MAGIC - Metin alanları standardize edilir.
# MAGIC - Geçersiz natural key kayıtları Silver dışında bırakılır.
# MAGIC - Yükleme logları `audit.etl_table_load_log` tablosuna yazılır.
# MAGIC

# COMMAND ----------

required_parameters = [
    "BatchID",
    "LoadMode",
    "ProcessDate",
    "ProcessDay",
    "ProcessWeek"
]

parameters = {}

for name in required_parameters:
    try:
        value = dbutils.widgets.get(name).strip()
    except Exception as exc:
        raise ValueError(
            f"{name} parametresi notebooka gelmedi."
        ) from exc

    if not value:
        raise ValueError(
            f"{name} parametresi boş geldi."
        )

    parameters[name] = value

print("Gelen parametreler:")
for key, value in parameters.items():
    print(f"{key} = {value!r}")

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG retail_marketing
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     TRIM(:BatchID) AS BatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     CAST(:ProcessWeek AS DECIMAL(10,0)) AS ProcessWeek
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Batch ve Bronze kaynak kontrolü
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     BatchID,
# MAGIC     ProcessDate,
# MAGIC     ProcessDay,
# MAGIC     ProcessWeek,
# MAGIC     LoadMode,
# MAGIC     BatchStatus
# MAGIC FROM retail_marketing.control.etl_batch_control
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 'product_raw' AS SourceName, COUNT(*) AS RowCount
# MAGIC FROM retail_marketing.bronze.product_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'household_demographic_raw', COUNT(*)
# MAGIC FROM retail_marketing.bronze.household_demographic_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'campaign_desc_raw', COUNT(*)
# MAGIC FROM retail_marketing.bronze.campaign_desc_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'campaign_target_raw', COUNT(*)
# MAGIC FROM retail_marketing.bronze.campaign_target_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'coupon_raw', COUNT(*)
# MAGIC FROM retail_marketing.bronze.coupon_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'causal_data_raw', COUNT(*)
# MAGIC FROM retail_marketing.bronze.causal_data_raw
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Product Silver kaynağını hazırla
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW product_silver_source AS
# MAGIC SELECT
# MAGIC     product_id,
# MAGIC     manufacturer,
# MAGIC     NULLIF(UPPER(TRIM(department)), '') AS department,
# MAGIC     NULLIF(UPPER(TRIM(brand)), '') AS brand,
# MAGIC     NULLIF(UPPER(TRIM(commodity_desc)), '') AS commodity_desc,
# MAGIC     NULLIF(UPPER(TRIM(sub_commodity_desc)), '') AS sub_commodity_desc,
# MAGIC     NULLIF(UPPER(TRIM(curr_size_of_product)), '') AS curr_size_of_product,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(product_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(manufacturer AS STRING), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(department)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(brand)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(commodity_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(sub_commodity_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(curr_size_of_product)), ''), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY product_id
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.product_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND product_id IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW product_profile AS
# MAGIC SELECT
# MAGIC     (SELECT COUNT(*) FROM retail_marketing.bronze.product_raw WHERE BatchID = TRIM(:BatchID)) AS BronzeRowCount,
# MAGIC     (SELECT COUNT(*) FROM product_silver_source) AS CleanRowCount,
# MAGIC     (SELECT COUNT(*) FROM retail_marketing.bronze.product_raw WHERE BatchID = TRIM(:BatchID) AND product_id IS NULL) AS RejectedRowCount,
# MAGIC     (
# MAGIC         SELECT COUNT(*) FROM retail_marketing.bronze.product_raw WHERE BatchID = TRIM(:BatchID) AND product_id IS NOT NULL
# MAGIC     ) - (SELECT COUNT(*) FROM product_silver_source) AS DuplicateRowCount
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Product Silver reload ve log
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_PRODUCT') AS ETLLogID,
# MAGIC         TRIM(:BatchID) AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         (SELECT BronzeRowCount FROM product_profile) AS SourceRowCount
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.BatchID = source.BatchID,
# MAGIC     target.LayerName = 'SILVER',
# MAGIC     target.SourceName = 'product_raw',
# MAGIC     target.TargetTableName = 'retail_marketing.silver.product_clean',
# MAGIC     target.LoadStrategy = 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     target.ProcessDate = source.ProcessDate,
# MAGIC     target.ProcessValue = NULL,
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = source.SourceRowCount,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName, LoadStrategy,
# MAGIC     ProcessDate, ProcessValue, StartTime, EndTime, SourceRowCount,
# MAGIC     InsertedRowCount, UpdatedRowCount, RejectedRowCount,
# MAGIC     UnchangedRowCount, LoadStatus, ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'SILVER', 'product_raw',
# MAGIC     'retail_marketing.silver.product_clean', 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     source.ProcessDate, NULL, current_timestamp(), NULL, source.SourceRowCount,
# MAGIC     0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.product_clean (
# MAGIC     product_id, manufacturer, department, brand, commodity_desc,
# MAGIC     sub_commodity_desc, curr_size_of_product, SourceBatchID,
# MAGIC     ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     product_id, manufacturer, department, brand, commodity_desc,
# MAGIC     sub_commodity_desc, curr_size_of_product, SourceBatchID,
# MAGIC     ProcessDate, current_timestamp(), RecordHash
# MAGIC FROM product_silver_source
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*) FROM retail_marketing.silver.product_clean
# MAGIC         WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     ),
# MAGIC     RejectedRowCount = (SELECT RejectedRowCount FROM product_profile),
# MAGIC     UnchangedRowCount = (SELECT DuplicateRowCount FROM product_profile),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT BronzeRowCount FROM product_profile) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT CleanRowCount FROM product_profile) = (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.silver.product_clean
# MAGIC             WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC         )
# MAGIC         THEN CASE
# MAGIC             WHEN (SELECT RejectedRowCount + DuplicateRowCount FROM product_profile) > 0
# MAGIC             THEN 'SUCCESS_WITH_WARNING'
# MAGIC             ELSE 'SUCCESS'
# MAGIC         END
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT BronzeRowCount FROM product_profile) = 0
# MAGIC             THEN 'Bronze product kaydı bulunamadı.'
# MAGIC         WHEN (SELECT CleanRowCount FROM product_profile) <> (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.silver.product_clean
# MAGIC             WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC         )
# MAGIC             THEN 'Product Silver kaynak-hedef satır sayıları eşleşmiyor.'
# MAGIC         WHEN (SELECT RejectedRowCount + DuplicateRowCount FROM product_profile) > 0
# MAGIC             THEN CONCAT(
# MAGIC                 'Rejected=', CAST((SELECT RejectedRowCount FROM product_profile) AS STRING),
# MAGIC                 ', Duplicate=', CAST((SELECT DuplicateRowCount FROM product_profile) AS STRING)
# MAGIC             )
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(TRIM(:BatchID), '_SILVER_PRODUCT')
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Household Silver kaynağını hazırla
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW household_silver_source AS
# MAGIC SELECT
# MAGIC     household_key,
# MAGIC     NULLIF(UPPER(TRIM(age_desc)), '') AS age_desc,
# MAGIC     NULLIF(UPPER(TRIM(marital_status_code)), '') AS marital_status_code,
# MAGIC     NULLIF(UPPER(TRIM(income_desc)), '') AS income_desc,
# MAGIC     NULLIF(UPPER(TRIM(homeowner_desc)), '') AS homeowner_desc,
# MAGIC     NULLIF(UPPER(TRIM(hh_comp_desc)), '') AS hh_comp_desc,
# MAGIC     NULLIF(UPPER(TRIM(household_size_desc)), '') AS household_size_desc,
# MAGIC     NULLIF(UPPER(TRIM(kid_category_desc)), '') AS kid_category_desc,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(household_key AS STRING), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(age_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(marital_status_code)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(income_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(homeowner_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(hh_comp_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(household_size_desc)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(kid_category_desc)), ''), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY household_key
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.household_demographic_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND household_key IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW household_profile AS
# MAGIC SELECT
# MAGIC     (SELECT COUNT(*) FROM retail_marketing.bronze.household_demographic_raw WHERE BatchID = TRIM(:BatchID)) AS BronzeRowCount,
# MAGIC     (SELECT COUNT(*) FROM household_silver_source) AS CleanRowCount,
# MAGIC     (SELECT COUNT(*) FROM retail_marketing.bronze.household_demographic_raw WHERE BatchID = TRIM(:BatchID) AND household_key IS NULL) AS RejectedRowCount,
# MAGIC     (
# MAGIC         SELECT COUNT(*) FROM retail_marketing.bronze.household_demographic_raw
# MAGIC         WHERE BatchID = TRIM(:BatchID) AND household_key IS NOT NULL
# MAGIC     ) - (SELECT COUNT(*) FROM household_silver_source) AS DuplicateRowCount
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_HOUSEHOLD') AS ETLLogID,
# MAGIC         TRIM(:BatchID) AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         (SELECT BronzeRowCount FROM household_profile) AS SourceRowCount
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.BatchID = source.BatchID,
# MAGIC     target.LayerName = 'SILVER',
# MAGIC     target.SourceName = 'household_demographic_raw',
# MAGIC     target.TargetTableName = 'retail_marketing.silver.household_demographic_clean',
# MAGIC     target.LoadStrategy = 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     target.ProcessDate = source.ProcessDate,
# MAGIC     target.ProcessValue = NULL,
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = NULL,
# MAGIC     target.SourceRowCount = source.SourceRowCount,
# MAGIC     target.InsertedRowCount = 0,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = 0,
# MAGIC     target.UnchangedRowCount = 0,
# MAGIC     target.LoadStatus = 'STARTED',
# MAGIC     target.ErrorMessage = NULL,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName, LoadStrategy,
# MAGIC     ProcessDate, ProcessValue, StartTime, EndTime, SourceRowCount,
# MAGIC     InsertedRowCount, UpdatedRowCount, RejectedRowCount,
# MAGIC     UnchangedRowCount, LoadStatus, ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'SILVER', 'household_demographic_raw',
# MAGIC     'retail_marketing.silver.household_demographic_clean',
# MAGIC     'CLEAN_DEDUPLICATE_RELOAD', source.ProcessDate, NULL,
# MAGIC     current_timestamp(), NULL, source.SourceRowCount,
# MAGIC     0, 0, 0, 0, 'STARTED', NULL, current_timestamp()
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.household_demographic_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.household_demographic_clean (
# MAGIC     household_key, age_desc, marital_status_code, income_desc,
# MAGIC     homeowner_desc, hh_comp_desc, household_size_desc,
# MAGIC     kid_category_desc, SourceBatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     household_key, age_desc, marital_status_code, income_desc,
# MAGIC     homeowner_desc, hh_comp_desc, household_size_desc,
# MAGIC     kid_category_desc, SourceBatchID, ProcessDate,
# MAGIC     current_timestamp(), RecordHash
# MAGIC FROM household_silver_source

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE retail_marketing.audit.etl_table_load_log
# MAGIC SET
# MAGIC     EndTime = current_timestamp(),
# MAGIC     InsertedRowCount = (
# MAGIC         SELECT COUNT(*) FROM retail_marketing.silver.household_demographic_clean
# MAGIC         WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     ),
# MAGIC     RejectedRowCount = (SELECT RejectedRowCount FROM household_profile),
# MAGIC     UnchangedRowCount = (SELECT DuplicateRowCount FROM household_profile),
# MAGIC     LoadStatus = CASE
# MAGIC         WHEN (SELECT BronzeRowCount FROM household_profile) = 0 THEN 'FAILED'
# MAGIC         WHEN (SELECT CleanRowCount FROM household_profile) = (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.silver.household_demographic_clean
# MAGIC             WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC         )
# MAGIC         THEN CASE
# MAGIC             WHEN (SELECT RejectedRowCount + DuplicateRowCount FROM household_profile) > 0
# MAGIC             THEN 'SUCCESS_WITH_WARNING'
# MAGIC             ELSE 'SUCCESS'
# MAGIC         END
# MAGIC         ELSE 'FAILED'
# MAGIC     END,
# MAGIC     ErrorMessage = CASE
# MAGIC         WHEN (SELECT BronzeRowCount FROM household_profile) = 0
# MAGIC             THEN 'Bronze household kaydı bulunamadı.'
# MAGIC         WHEN (SELECT CleanRowCount FROM household_profile) <> (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.silver.household_demographic_clean
# MAGIC             WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC         )
# MAGIC             THEN 'Household Silver kaynak-hedef satır sayıları eşleşmiyor.'
# MAGIC         WHEN (SELECT RejectedRowCount + DuplicateRowCount FROM household_profile) > 0
# MAGIC             THEN CONCAT(
# MAGIC                 'Rejected=', CAST((SELECT RejectedRowCount FROM household_profile) AS STRING),
# MAGIC                 ', Duplicate=', CAST((SELECT DuplicateRowCount FROM household_profile) AS STRING)
# MAGIC             )
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     ETLTime = current_timestamp()
# MAGIC WHERE ETLLogID = CONCAT(TRIM(:BatchID), '_SILVER_HOUSEHOLD')
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Campaign Silver kaynağını hazırla
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW campaign_silver_source AS
# MAGIC SELECT
# MAGIC     campaign_id,
# MAGIC     NULLIF(UPPER(TRIM(description)), '') AS description,
# MAGIC     start_day,
# MAGIC     end_day,
# MAGIC     CASE
# MAGIC         WHEN start_day IS NOT NULL
# MAGIC          AND end_day IS NOT NULL
# MAGIC          AND end_day >= start_day
# MAGIC         THEN end_day - start_day + 1
# MAGIC         ELSE NULL
# MAGIC     END AS campaign_duration,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(campaign_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(description)), ''), '<NULL>'),
# MAGIC             COALESCE(CAST(start_day AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(end_day AS STRING), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY campaign_id
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.campaign_desc_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND campaign_id IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.campaign_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.campaign_clean (
# MAGIC     campaign_id, description, start_day, end_day, campaign_duration,
# MAGIC     SourceBatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     campaign_id, description, start_day, end_day, campaign_duration,
# MAGIC     SourceBatchID, ProcessDate, current_timestamp(), RecordHash
# MAGIC FROM campaign_silver_source
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_CAMPAIGN') AS ETLLogID,
# MAGIC         TRIM(:BatchID) AS BatchID,
# MAGIC         CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.bronze.campaign_desc_raw WHERE BatchID = TRIM(:BatchID)) AS SourceRowCount,
# MAGIC         (SELECT COUNT(*) FROM campaign_silver_source) AS InsertedRowCount,
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.bronze.campaign_desc_raw WHERE BatchID = TRIM(:BatchID) AND campaign_id IS NULL) AS RejectedRowCount
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.BatchID = source.BatchID,
# MAGIC     target.LayerName = 'SILVER',
# MAGIC     target.SourceName = 'campaign_desc_raw',
# MAGIC     target.TargetTableName = 'retail_marketing.silver.campaign_clean',
# MAGIC     target.LoadStrategy = 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     target.ProcessDate = source.ProcessDate,
# MAGIC     target.ProcessValue = NULL,
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = current_timestamp(),
# MAGIC     target.SourceRowCount = source.SourceRowCount,
# MAGIC     target.InsertedRowCount = source.InsertedRowCount,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = source.RejectedRowCount,
# MAGIC     target.UnchangedRowCount = source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount,
# MAGIC     target.LoadStatus = CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'FAILED'
# MAGIC         WHEN source.RejectedRowCount > 0 OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC             THEN 'SUCCESS_WITH_WARNING'
# MAGIC         ELSE 'SUCCESS'
# MAGIC     END,
# MAGIC     target.ErrorMessage = CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'Bronze campaign kaydı bulunamadı.'
# MAGIC         WHEN source.RejectedRowCount > 0 OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC             THEN 'Campaign kayıtlarında rejected veya duplicate bulundu.'
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName, LoadStrategy,
# MAGIC     ProcessDate, ProcessValue, StartTime, EndTime, SourceRowCount,
# MAGIC     InsertedRowCount, UpdatedRowCount, RejectedRowCount,
# MAGIC     UnchangedRowCount, LoadStatus, ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'SILVER', 'campaign_desc_raw',
# MAGIC     'retail_marketing.silver.campaign_clean', 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     source.ProcessDate, NULL, current_timestamp(), current_timestamp(),
# MAGIC     source.SourceRowCount, source.InsertedRowCount, 0,
# MAGIC     source.RejectedRowCount,
# MAGIC     source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount,
# MAGIC     CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'FAILED'
# MAGIC         WHEN source.RejectedRowCount > 0 OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC             THEN 'SUCCESS_WITH_WARNING'
# MAGIC         ELSE 'SUCCESS'
# MAGIC     END,
# MAGIC     CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'Bronze campaign kaydı bulunamadı.'
# MAGIC         WHEN source.RejectedRowCount > 0 OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC             THEN 'Campaign kayıtlarında rejected veya duplicate bulundu.'
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     current_timestamp()
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Campaign target Silver
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW campaign_target_silver_source AS
# MAGIC SELECT
# MAGIC     household_key,
# MAGIC     campaign_id,
# MAGIC     NULLIF(UPPER(TRIM(description)), '') AS description,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(household_key AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(campaign_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(description)), ''), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY household_key, campaign_id
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.campaign_target_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND household_key IS NOT NULL
# MAGIC       AND campaign_id IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.campaign_target_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.campaign_target_clean (
# MAGIC     household_key, campaign_id, description,
# MAGIC     SourceBatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     household_key, campaign_id, description,
# MAGIC     SourceBatchID, ProcessDate, current_timestamp(), RecordHash
# MAGIC FROM campaign_target_silver_source
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Coupon-product Silver
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW coupon_product_silver_source AS
# MAGIC SELECT
# MAGIC     coupon_upc,
# MAGIC     product_id,
# MAGIC     campaign_id,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(coupon_upc AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(product_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(campaign_id AS STRING), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY coupon_upc, product_id, campaign_id
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.coupon_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND coupon_upc IS NOT NULL
# MAGIC       AND product_id IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.coupon_product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.coupon_product_clean (
# MAGIC     coupon_upc, product_id, campaign_id,
# MAGIC     SourceBatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     coupon_upc, product_id, campaign_id,
# MAGIC     SourceBatchID, ProcessDate, current_timestamp(), RecordHash
# MAGIC FROM coupon_product_silver_source
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Promotion weekly Silver
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW promotion_weekly_silver_source AS
# MAGIC SELECT
# MAGIC     product_id,
# MAGIC     store_id,
# MAGIC     week_no,
# MAGIC     NULLIF(UPPER(TRIM(display_code)), '') AS display_code,
# MAGIC     NULLIF(UPPER(TRIM(mailer_code)), '') AS mailer_code,
# MAGIC     CASE
# MAGIC         WHEN display_code IS NULL
# MAGIC           OR TRIM(display_code) = ''
# MAGIC           OR UPPER(TRIM(display_code)) IN ('0', 'N', 'NONE')
# MAGIC         THEN 'N'
# MAGIC         ELSE 'Y'
# MAGIC     END AS has_display,
# MAGIC     CASE
# MAGIC         WHEN mailer_code IS NULL
# MAGIC           OR TRIM(mailer_code) = ''
# MAGIC           OR UPPER(TRIM(mailer_code)) IN ('0', 'N', 'NONE')
# MAGIC         THEN 'N'
# MAGIC         ELSE 'Y'
# MAGIC     END AS has_mailer,
# MAGIC     TRIM(:BatchID) AS SourceBatchID,
# MAGIC     CAST(:ProcessDate AS DATE) AS ProcessDate,
# MAGIC     SHA2(
# MAGIC         CONCAT_WS(
# MAGIC             '||',
# MAGIC             COALESCE(CAST(product_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(store_id AS STRING), '<NULL>'),
# MAGIC             COALESCE(CAST(week_no AS STRING), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(display_code)), ''), '<NULL>'),
# MAGIC             COALESCE(NULLIF(UPPER(TRIM(mailer_code)), ''), '<NULL>')
# MAGIC         ),
# MAGIC         256
# MAGIC     ) AS RecordHash
# MAGIC FROM (
# MAGIC     SELECT
# MAGIC         source.*,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY product_id, store_id, week_no
# MAGIC             ORDER BY ETLTime DESC, RecordHash DESC
# MAGIC         ) AS RowNumber
# MAGIC     FROM retail_marketing.bronze.causal_data_raw AS source
# MAGIC     WHERE BatchID = TRIM(:BatchID)
# MAGIC       AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC       AND product_id IS NOT NULL
# MAGIC       AND store_id IS NOT NULL
# MAGIC       AND week_no IS NOT NULL
# MAGIC )
# MAGIC WHERE RowNumber = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.silver.promotion_weekly_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.silver.promotion_weekly_clean (
# MAGIC     product_id, store_id, week_no, display_code, mailer_code,
# MAGIC     has_display, has_mailer, SourceBatchID, ProcessDate, ETLTime, RecordHash
# MAGIC )
# MAGIC SELECT
# MAGIC     product_id, store_id, week_no, display_code, mailer_code,
# MAGIC     has_display, has_mailer, SourceBatchID, ProcessDate,
# MAGIC     current_timestamp(), RecordHash
# MAGIC FROM promotion_weekly_silver_source
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Son üç kaynak için yükleme loglarını yaz
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO retail_marketing.audit.etl_table_load_log AS target
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_CAMPAIGN_TARGET') AS ETLLogID,
# MAGIC         TRIM(:BatchID) AS BatchID,
# MAGIC         'campaign_target_raw' AS SourceName,
# MAGIC         'retail_marketing.silver.campaign_target_clean' AS TargetTableName,
# MAGIC         CAST(NULL AS DECIMAL(20,0)) AS ProcessValue,
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.bronze.campaign_target_raw WHERE BatchID = TRIM(:BatchID)) AS SourceRowCount,
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.silver.campaign_target_clean WHERE SourceBatchID = TRIM(:BatchID)) AS InsertedRowCount,
# MAGIC         (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.bronze.campaign_target_raw
# MAGIC             WHERE BatchID = TRIM(:BatchID)
# MAGIC               AND (household_key IS NULL OR campaign_id IS NULL)
# MAGIC         ) AS RejectedRowCount
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_COUPON_PRODUCT'),
# MAGIC         TRIM(:BatchID),
# MAGIC         'coupon_raw',
# MAGIC         'retail_marketing.silver.coupon_product_clean',
# MAGIC         CAST(NULL AS DECIMAL(20,0)),
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.bronze.coupon_raw WHERE BatchID = TRIM(:BatchID)),
# MAGIC         (SELECT COUNT(*) FROM retail_marketing.silver.coupon_product_clean WHERE SourceBatchID = TRIM(:BatchID)),
# MAGIC         (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.bronze.coupon_raw
# MAGIC             WHERE BatchID = TRIM(:BatchID)
# MAGIC               AND (coupon_upc IS NULL OR product_id IS NULL)
# MAGIC         )
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CONCAT(TRIM(:BatchID), '_SILVER_PROMOTION_WEEKLY'),
# MAGIC         TRIM(:BatchID),
# MAGIC         'causal_data_raw',
# MAGIC         'retail_marketing.silver.promotion_weekly_clean',
# MAGIC         CAST(:ProcessWeek AS DECIMAL(20,0)),
# MAGIC         (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.bronze.causal_data_raw
# MAGIC             WHERE BatchID = TRIM(:BatchID)
# MAGIC               AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC         ),
# MAGIC         (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.silver.promotion_weekly_clean
# MAGIC             WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC         ),
# MAGIC         (
# MAGIC             SELECT COUNT(*) FROM retail_marketing.bronze.causal_data_raw
# MAGIC             WHERE BatchID = TRIM(:BatchID)
# MAGIC               AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC               AND (product_id IS NULL OR store_id IS NULL OR week_no IS NULL)
# MAGIC         )
# MAGIC ) AS source
# MAGIC ON target.ETLLogID = source.ETLLogID
# MAGIC
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     target.BatchID = source.BatchID,
# MAGIC     target.LayerName = 'SILVER',
# MAGIC     target.SourceName = source.SourceName,
# MAGIC     target.TargetTableName = source.TargetTableName,
# MAGIC     target.LoadStrategy = 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     target.ProcessDate = CAST(:ProcessDate AS DATE),
# MAGIC     target.ProcessValue = source.ProcessValue,
# MAGIC     target.StartTime = current_timestamp(),
# MAGIC     target.EndTime = current_timestamp(),
# MAGIC     target.SourceRowCount = source.SourceRowCount,
# MAGIC     target.InsertedRowCount = source.InsertedRowCount,
# MAGIC     target.UpdatedRowCount = 0,
# MAGIC     target.RejectedRowCount = source.RejectedRowCount,
# MAGIC     target.UnchangedRowCount = source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount,
# MAGIC     target.LoadStatus = CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'FAILED'
# MAGIC         WHEN source.RejectedRowCount > 0
# MAGIC           OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC         THEN 'SUCCESS_WITH_WARNING'
# MAGIC         ELSE 'SUCCESS'
# MAGIC     END,
# MAGIC     target.ErrorMessage = CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'Bronze kaynak kaydı bulunamadı.'
# MAGIC         WHEN source.RejectedRowCount > 0
# MAGIC           OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC         THEN 'Rejected veya duplicate kayıtlar bulundu.'
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     target.ETLTime = current_timestamp()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     ETLLogID, BatchID, LayerName, SourceName, TargetTableName, LoadStrategy,
# MAGIC     ProcessDate, ProcessValue, StartTime, EndTime, SourceRowCount,
# MAGIC     InsertedRowCount, UpdatedRowCount, RejectedRowCount,
# MAGIC     UnchangedRowCount, LoadStatus, ErrorMessage, ETLTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     source.ETLLogID, source.BatchID, 'SILVER', source.SourceName,
# MAGIC     source.TargetTableName, 'CLEAN_DEDUPLICATE_RELOAD',
# MAGIC     CAST(:ProcessDate AS DATE), source.ProcessValue,
# MAGIC     current_timestamp(), current_timestamp(),
# MAGIC     source.SourceRowCount, source.InsertedRowCount, 0,
# MAGIC     source.RejectedRowCount,
# MAGIC     source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount,
# MAGIC     CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'FAILED'
# MAGIC         WHEN source.RejectedRowCount > 0
# MAGIC           OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC         THEN 'SUCCESS_WITH_WARNING'
# MAGIC         ELSE 'SUCCESS'
# MAGIC     END,
# MAGIC     CASE
# MAGIC         WHEN source.SourceRowCount = 0 THEN 'Bronze kaynak kaydı bulunamadı.'
# MAGIC         WHEN source.RejectedRowCount > 0
# MAGIC           OR source.SourceRowCount - source.RejectedRowCount - source.InsertedRowCount > 0
# MAGIC         THEN 'Rejected veya duplicate kayıtlar bulundu.'
# MAGIC         ELSE NULL
# MAGIC     END,
# MAGIC     current_timestamp()
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Sonuç kontrolleri
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 'product_clean' AS TableName, COUNT(*) AS RowCount
# MAGIC FROM retail_marketing.silver.product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'household_demographic_clean', COUNT(*)
# MAGIC FROM retail_marketing.silver.household_demographic_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'campaign_clean', COUNT(*)
# MAGIC FROM retail_marketing.silver.campaign_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'campaign_target_clean', COUNT(*)
# MAGIC FROM retail_marketing.silver.campaign_target_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'coupon_product_clean', COUNT(*)
# MAGIC FROM retail_marketing.silver.coupon_product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'promotion_weekly_clean', COUNT(*)
# MAGIC FROM retail_marketing.silver.promotion_weekly_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     SourceName,
# MAGIC     TargetTableName,
# MAGIC     SourceRowCount,
# MAGIC     InsertedRowCount,
# MAGIC     RejectedRowCount,
# MAGIC     UnchangedRowCount,
# MAGIC     LoadStatus,
# MAGIC     ErrorMessage
# MAGIC FROM retail_marketing.audit.etl_table_load_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC   AND SourceName IN (
# MAGIC       'product_raw',
# MAGIC       'household_demographic_raw',
# MAGIC       'campaign_desc_raw',
# MAGIC       'campaign_target_raw',
# MAGIC       'coupon_raw',
# MAGIC       'causal_data_raw'
# MAGIC   )
# MAGIC ORDER BY SourceName
# MAGIC