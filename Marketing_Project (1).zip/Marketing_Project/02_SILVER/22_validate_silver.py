# Databricks notebook source
# MAGIC %md
# MAGIC # 22_validate_silver — Working Version
# MAGIC
# MAGIC Bu notebook seçilen batch için Silver katmanını doğrular ve sonuçları
# MAGIC `retail_marketing.audit.data_quality_log` tablosuna yazar.
# MAGIC
# MAGIC Kontroller:
# MAGIC - Silver tablolarının doluluk durumu
# MAGIC - Transaction ve coupon redemption gün kontrolü
# MAGIC - Natural key null kontrolleri
# MAGIC - Natural key duplicate kontrolleri
# MAGIC - Campaign tarih kuralı
# MAGIC - Promotion hafta kontrolü
# MAGIC - Silver yükleme loglarının durumu
# MAGIC - Temel referential integrity kontrolleri
# MAGIC
# MAGIC Parametreler:
# MAGIC - `BatchID`
# MAGIC - `ProcessDay`
# MAGIC - `ProcessWeek`
# MAGIC

# COMMAND ----------

required_parameters = [
    "BatchID",
    "LoadMode",
    "ProcessDate",
    "ProcessDay",
    "ProcessWeek"
]

parameters = {}

for name in required_parameters:
    try:
        value = dbutils.widgets.get(name).strip()
    except Exception as exc:
        raise ValueError(
            f"{name} parametresi notebooka gelmedi."
        ) from exc

    if not value:
        raise ValueError(
            f"{name} parametresi boş geldi."
        )

    parameters[name] = value

print("Gelen parametreler:")
for key, value in parameters.items():
    print(f"{key} = {value!r}")

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG retail_marketing
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     TRIM(:BatchID) AS BatchID,
# MAGIC     CAST(:ProcessDay AS DECIMAL(10,0)) AS ProcessDay,
# MAGIC     CAST(:ProcessWeek AS DECIMAL(10,0)) AS ProcessWeek
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Batch kontrolü
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     BatchID,
# MAGIC     ProcessDate,
# MAGIC     ProcessDay,
# MAGIC     ProcessWeek,
# MAGIC     LoadMode,
# MAGIC     BatchStatus
# MAGIC FROM retail_marketing.control.etl_batch_control
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Aynı batch'e ait eski Silver kalite loglarını temizle
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Silver kalite sonuçlarını hazırla
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW silver_dq_results AS
# MAGIC
# MAGIC -- 1) Transaction Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_TRANSACTION_NOT_EMPTY') AS DQLogID,
# MAGIC     TRIM(:BatchID) AS BatchID,
# MAGIC     'SILVER' AS LayerName,
# MAGIC     'retail_marketing.silver.transaction_clean' AS TableName,
# MAGIC     'transaction_silver_not_empty' AS CheckName,
# MAGIC     'RECONCILIATION' AS CheckCategory,
# MAGIC     'CRITICAL' AS SeverityLevel,
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)) AS CheckedRowCount,
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)) AS PassedRowCount,
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)) AS FailedRowCount,
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)) AS FailureRate,
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END AS CheckStatus,
# MAGIC     'İlgili batch için Silver transaction kaydı bulunmalıdır.' AS CheckDescription
# MAGIC FROM retail_marketing.silver.transaction_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 2) Product Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_PRODUCT_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.product_clean',
# MAGIC     'product_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için Silver product kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 3) Household Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_HOUSEHOLD_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.household_demographic_clean',
# MAGIC     'household_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için Silver household kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.household_demographic_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 4) Campaign Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_clean',
# MAGIC     'campaign_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için Silver campaign kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.campaign_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 5) Campaign target Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_TARGET_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_target_clean',
# MAGIC     'campaign_target_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için Silver campaign target kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.campaign_target_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 6) Coupon product Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_COUPON_PRODUCT_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.coupon_product_clean',
# MAGIC     'coupon_product_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch için Silver coupon-product kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.coupon_product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 7) Promotion weekly Silver boş olmamalı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_PROMOTION_NOT_EMPTY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.promotion_weekly_clean',
# MAGIC     'promotion_weekly_silver_not_empty',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN COUNT(*) ELSE 0 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'İlgili batch ve hafta için Silver promotion kaydı bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.promotion_weekly_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC   AND week_no = CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 8) Transaction DAY kontrolü
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_TRANSACTION_PROCESS_DAY'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.transaction_clean',
# MAGIC     'transaction_process_day_check',
# MAGIC     'BUSINESS_RULE', 'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 0
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) / COUNT(*) END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN day_no IS NULL OR day_no <> CAST(:ProcessDay AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Transaction DAY değeri ProcessDay ile aynı olmalıdır.'
# MAGIC FROM retail_marketing.silver.transaction_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 9) Transaction zorunlu alanlar
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_TRANSACTION_REQUIRED_FIELDS'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.transaction_clean',
# MAGIC     'transaction_required_fields',
# MAGIC     'NOT_NULL', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC               OR quantity IS NULL
# MAGIC               OR sales_value IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC               OR quantity IS NULL
# MAGIC               OR sales_value IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 0
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC               OR quantity IS NULL
# MAGIC               OR sales_value IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0) / COUNT(*) END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN basket_id IS NULL
# MAGIC               OR product_id IS NULL
# MAGIC               OR day_no IS NULL
# MAGIC               OR quantity IS NULL
# MAGIC               OR sales_value IS NULL
# MAGIC               OR RecordHash IS NULL
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Silver transaction zorunlu alanları dolu olmalıdır.'
# MAGIC FROM retail_marketing.silver.transaction_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 10) Transaction RecordHash duplicate
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_TRANSACTION_HASH_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.transaction_clean',
# MAGIC     'transaction_recordhash_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.transaction_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Silver transaction içinde duplicate RecordHash bulunmamalıdır.'
# MAGIC FROM (
# MAGIC     SELECT RecordHash
# MAGIC     FROM retail_marketing.silver.transaction_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY RecordHash
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 11) Product natural key null
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_PRODUCT_ID_NOT_NULL'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.product_clean',
# MAGIC     'product_id_not_null',
# MAGIC     'NOT_NULL', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Silver product_id null olmamalıdır.'
# MAGIC FROM retail_marketing.silver.product_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 12) Product key unique
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_PRODUCT_ID_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.product_clean',
# MAGIC     'product_id_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.product_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Silver product_id benzersiz olmalıdır.'
# MAGIC FROM (
# MAGIC     SELECT product_id
# MAGIC     FROM retail_marketing.silver.product_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY product_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 13) Household key unique
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_HOUSEHOLD_KEY_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.household_demographic_clean',
# MAGIC     'household_key_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.household_demographic_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Silver household_key benzersiz olmalıdır.'
# MAGIC FROM (
# MAGIC     SELECT household_key
# MAGIC     FROM retail_marketing.silver.household_demographic_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY household_key
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 14) Campaign key unique
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_ID_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_clean',
# MAGIC     'campaign_id_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.campaign_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Silver campaign_id benzersiz olmalıdır.'
# MAGIC FROM (
# MAGIC     SELECT campaign_id
# MAGIC     FROM retail_marketing.silver.campaign_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY campaign_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 15) Campaign tarih kuralı
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_DATE_RULE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_clean',
# MAGIC     'campaign_date_rule',
# MAGIC     'BUSINESS_RULE', 'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN start_day IS NULL
# MAGIC               OR end_day IS NULL
# MAGIC               OR end_day < start_day
# MAGIC               OR campaign_duration IS NULL
# MAGIC               OR campaign_duration <= 0
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN start_day IS NULL
# MAGIC               OR end_day IS NULL
# MAGIC               OR end_day < start_day
# MAGIC               OR campaign_duration IS NULL
# MAGIC               OR campaign_duration <= 0
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 0
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN start_day IS NULL
# MAGIC               OR end_day IS NULL
# MAGIC               OR end_day < start_day
# MAGIC               OR campaign_duration IS NULL
# MAGIC               OR campaign_duration <= 0
# MAGIC             THEN 1 ELSE 0 END), 0) / COUNT(*) END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN start_day IS NULL
# MAGIC               OR end_day IS NULL
# MAGIC               OR end_day < start_day
# MAGIC               OR campaign_duration IS NULL
# MAGIC               OR campaign_duration <= 0
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Campaign end_day >= start_day ve duration > 0 olmalıdır.'
# MAGIC FROM retail_marketing.silver.campaign_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 16) Campaign target grain unique
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_TARGET_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_target_clean',
# MAGIC     'campaign_target_grain_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.campaign_target_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'household_key + campaign_id kombinasyonu benzersiz olmalıdır.'
# MAGIC FROM (
# MAGIC     SELECT household_key, campaign_id
# MAGIC     FROM retail_marketing.silver.campaign_target_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY household_key, campaign_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 17) Coupon-product grain unique
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_COUPON_PRODUCT_UNIQUE'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.coupon_product_clean',
# MAGIC     'coupon_product_grain_unique',
# MAGIC     'UNIQUENESS', 'CRITICAL',
# MAGIC     CAST((SELECT COUNT(*) FROM retail_marketing.silver.coupon_product_clean WHERE SourceBatchID = TRIM(:BatchID)) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(NULL AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'coupon_upc + product_id + campaign_id kombinasyonu benzersiz olmalıdır.'
# MAGIC FROM (
# MAGIC     SELECT coupon_upc, product_id, campaign_id
# MAGIC     FROM retail_marketing.silver.coupon_product_clean
# MAGIC     WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC     GROUP BY coupon_upc, product_id, campaign_id
# MAGIC     HAVING COUNT(*) > 1
# MAGIC ) d
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 18) Promotion hafta kontrolü
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_PROMOTION_WEEK'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.promotion_weekly_clean',
# MAGIC     'promotion_process_week_check',
# MAGIC     'BUSINESS_RULE', 'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN week_no IS NULL OR week_no <> CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         COALESCE(SUM(CASE
# MAGIC             WHEN week_no IS NULL OR week_no <> CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 0
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN week_no IS NULL OR week_no <> CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) / COUNT(*) END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN week_no IS NULL OR week_no <> CAST(:ProcessWeek AS DECIMAL(10,0))
# MAGIC             THEN 1 ELSE 0 END), 0) = 0
# MAGIC         THEN 'PASS' ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Promotion week_no değeri ProcessWeek ile aynı olmalıdır.'
# MAGIC FROM retail_marketing.silver.promotion_weekly_clean
# MAGIC WHERE SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 19) Campaign target -> campaign RI
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_CAMPAIGN_TARGET_CAMPAIGN_RI'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.campaign_target_clean',
# MAGIC     'campaign_target_campaign_referential_integrity',
# MAGIC     'REFERENTIAL_INTEGRITY', 'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN c.campaign_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN c.campaign_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN c.campaign_id IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN c.campaign_id IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Campaign target içindeki campaign_id, Silver campaign tablosunda bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.campaign_target_clean t
# MAGIC LEFT JOIN retail_marketing.silver.campaign_clean c
# MAGIC     ON c.campaign_id = t.campaign_id
# MAGIC WHERE t.SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 20) Coupon-product -> product RI
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_COUPON_PRODUCT_PRODUCT_RI'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.silver.coupon_product_clean',
# MAGIC     'coupon_product_product_referential_integrity',
# MAGIC     'REFERENTIAL_INTEGRITY', 'ERROR',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(COUNT(*) - COALESCE(SUM(CASE WHEN p.product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(COALESCE(SUM(CASE WHEN p.product_id IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(20,0)),
# MAGIC     CAST(CASE WHEN COUNT(*) = 0 THEN 0 ELSE COALESCE(SUM(CASE WHEN p.product_id IS NULL THEN 1 ELSE 0 END), 0) / COUNT(*) END AS DECIMAL(18,6)),
# MAGIC     CASE WHEN COALESCE(SUM(CASE WHEN p.product_id IS NULL THEN 1 ELSE 0 END), 0) = 0 THEN 'PASS' ELSE 'FAIL' END,
# MAGIC     'Coupon-product içindeki product_id, Silver product tablosunda bulunmalıdır.'
# MAGIC FROM retail_marketing.silver.coupon_product_clean cp
# MAGIC LEFT JOIN retail_marketing.silver.product_clean p
# MAGIC     ON p.product_id = cp.product_id
# MAGIC WHERE cp.SourceBatchID = TRIM(:BatchID)
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC -- 21) Silver load status
# MAGIC SELECT
# MAGIC     CONCAT(TRIM(:BatchID), '_DQ_SILVER_LOAD_STATUS'),
# MAGIC     TRIM(:BatchID), 'SILVER',
# MAGIC     'retail_marketing.audit.etl_table_load_log',
# MAGIC     'silver_load_status_check',
# MAGIC     'RECONCILIATION', 'CRITICAL',
# MAGIC     CAST(COUNT(*) AS DECIMAL(20,0)),
# MAGIC     CAST(
# MAGIC         COUNT(*) - COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0)
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 1
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0) END
# MAGIC         AS DECIMAL(20,0)
# MAGIC     ),
# MAGIC     CAST(
# MAGIC         CASE WHEN COUNT(*) = 0 THEN 1
# MAGIC         ELSE COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0) / COUNT(*) END
# MAGIC         AS DECIMAL(18,6)
# MAGIC     ),
# MAGIC     CASE
# MAGIC         WHEN COUNT(*) = 0 THEN 'FAIL'
# MAGIC         WHEN COALESCE(SUM(CASE
# MAGIC             WHEN LoadStatus IN ('SUCCESS', 'SUCCESS_WITH_WARNING', 'SKIPPED')
# MAGIC             THEN 0 ELSE 1 END), 0) = 0
# MAGIC         THEN 'PASS'
# MAGIC         ELSE 'FAIL'
# MAGIC     END,
# MAGIC     'Silver yükleme logları SUCCESS, SUCCESS_WITH_WARNING veya SKIPPED olmalıdır.'
# MAGIC FROM retail_marketing.audit.etl_table_load_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Sonuçları audit tablosuna yaz
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO retail_marketing.audit.data_quality_log (
# MAGIC     DQLogID,
# MAGIC     BatchID,
# MAGIC     LayerName,
# MAGIC     TableName,
# MAGIC     CheckName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription,
# MAGIC     ETLTime
# MAGIC )
# MAGIC SELECT
# MAGIC     DQLogID,
# MAGIC     BatchID,
# MAGIC     LayerName,
# MAGIC     TableName,
# MAGIC     CheckName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription,
# MAGIC     current_timestamp()
# MAGIC FROM silver_dq_results
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Detaylı sonuçlar
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     CheckName,
# MAGIC     TableName,
# MAGIC     CheckCategory,
# MAGIC     SeverityLevel,
# MAGIC     CheckedRowCount,
# MAGIC     PassedRowCount,
# MAGIC     FailedRowCount,
# MAGIC     FailureRate,
# MAGIC     CheckStatus,
# MAGIC     CheckDescription
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC ORDER BY
# MAGIC     CASE CheckStatus
# MAGIC         WHEN 'FAIL' THEN 1
# MAGIC         WHEN 'WARN' THEN 2
# MAGIC         WHEN 'PASS' THEN 3
# MAGIC         ELSE 4
# MAGIC     END,
# MAGIC     TableName,
# MAGIC     CheckName
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Özet
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     CheckStatus,
# MAGIC     COUNT(*) AS CheckCount
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC GROUP BY CheckStatus
# MAGIC ORDER BY CheckStatus
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     COUNT(*) AS CriticalFailureCount
# MAGIC FROM retail_marketing.audit.data_quality_log
# MAGIC WHERE BatchID = TRIM(:BatchID)
# MAGIC   AND LayerName = 'SILVER'
# MAGIC   AND CheckStatus = 'FAIL'
# MAGIC   AND SeverityLevel IN ('ERROR', 'CRITICAL')
# MAGIC