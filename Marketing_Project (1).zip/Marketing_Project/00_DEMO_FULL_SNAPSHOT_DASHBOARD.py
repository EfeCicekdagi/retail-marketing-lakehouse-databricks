# Databricks notebook source
# MAGIC %md
# MAGIC # Demo Full Snapshot — Dashboard Ready
# MAGIC
# MAGIC Bu notebook mevcut üretim pipeline'ına dokunmaz.
# MAGIC
# MAGIC Ayrı demo şemaları oluşturur:
# MAGIC
# MAGIC - `retail_marketing.demo_bronze`
# MAGIC - `retail_marketing.demo_silver`
# MAGIC - `retail_marketing.demo_gold`
# MAGIC - `retail_marketing.demo_dm`
# MAGIC
# MAGIC Log, batch control ve data quality tabloları kullanılmaz.
# MAGIC
# MAGIC Amaç: CSV dosyalarındaki tüm veriyi tek seferde Bronze → Silver → Gold → Data Mart akışından geçirip dashboard için hazır hale getirmek.
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG retail_marketing
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Demo şemalarını oluştur
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS retail_marketing.demo_bronze;
# MAGIC CREATE SCHEMA IF NOT EXISTS retail_marketing.demo_silver;
# MAGIC CREATE SCHEMA IF NOT EXISTS retail_marketing.demo_gold;
# MAGIC CREATE SCHEMA IF NOT EXISTS retail_marketing.demo_dm;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Bronze — CSV dosyalarının tamamını yükle
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### CSV dosyalarını Spark ile yükle
# MAGIC
# MAGIC `read_files()` yerine doğrudan Spark CSV okuyucusu kullanılır. Böylece notebook, Volume yolunu görebilen standart Databricks compute üzerinde çalışır.
# MAGIC

# COMMAND ----------

base_path = "/Volumes/retail_marketing/source/source_files/master"

csv_tables = {
    "transaction_data.csv": "transaction_data_raw",
    "product.csv": "product_raw",
    "coupon.csv": "coupon_raw",
    "coupon_redempt.csv": "coupon_redemption_raw",
    "hh_demographic.csv": "household_demographic_raw",
    "campaign_desc.csv": "campaign_desc_raw",
    "campaign_table.csv": "campaign_target_raw",
    "causal_data.csv": "causal_data_raw"
}

# Önce Volume yolunu ve gerekli dosyaları doğrula.
available_files = {f.name for f in dbutils.fs.ls(base_path)}
missing_files = [name for name in csv_tables if name not in available_files]

if missing_files:
    raise FileNotFoundError(
        f"Eksik CSV dosyaları: {missing_files}. Kontrol edilen yol: {base_path}"
    )

load_results = []

for file_name, table_name in csv_tables.items():
    file_path = f"{base_path}/{file_name}"
    target_table = f"retail_marketing.demo_bronze.{table_name}"

    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .option("mode", "FAILFAST")
        .csv(file_path)
    )

    row_count = df.count()

    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(target_table)
    )

    load_results.append((file_name, target_table, row_count))
    print(f"Yüklendi: {file_name} -> {target_table} | Satır: {row_count}")

load_result_df = spark.createDataFrame(
    load_results,
    ["SourceFile", "TargetTable", "RowCount"]
)

display(load_result_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Silver — Temiz ve tipleri düzenlenmiş tablolar
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.transaction_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   TRY_CAST(household_key AS INT) AS HouseholdID,
# MAGIC   TRY_CAST(BASKET_ID AS BIGINT) AS BasketID,
# MAGIC   TRY_CAST(DAY AS INT) AS DayNumber,
# MAGIC   TRY_CAST(PRODUCT_ID AS INT) AS ProductID,
# MAGIC   TRY_CAST(QUANTITY AS INT) AS Quantity,
# MAGIC   TRY_CAST(SALES_VALUE AS DECIMAL(18,2)) AS NetSalesAmount,
# MAGIC   TRY_CAST(STORE_ID AS INT) AS StoreID,
# MAGIC   TRY_CAST(RETAIL_DISC AS DECIMAL(18,2)) AS RetailDiscount,
# MAGIC   TRY_CAST(TRANS_TIME AS INT) AS TransactionTime,
# MAGIC   TRY_CAST(WEEK_NO AS INT) AS WeekNumber,
# MAGIC   TRY_CAST(COUPON_DISC AS DECIMAL(18,2)) AS CouponDiscount,
# MAGIC   TRY_CAST(COUPON_MATCH_DISC AS DECIMAL(18,2)) AS CouponMatchDiscount,
# MAGIC   CAST(
# MAGIC       ABS(COALESCE(TRY_CAST(RETAIL_DISC AS DECIMAL(18,2)), 0))
# MAGIC     + ABS(COALESCE(TRY_CAST(COUPON_DISC AS DECIMAL(18,2)), 0))
# MAGIC     + ABS(COALESCE(TRY_CAST(COUPON_MATCH_DISC AS DECIMAL(18,2)), 0))
# MAGIC     AS DECIMAL(18,2)
# MAGIC   ) AS TotalDiscountAmount,
# MAGIC   CAST(
# MAGIC       COALESCE(TRY_CAST(SALES_VALUE AS DECIMAL(18,2)), 0)
# MAGIC     + ABS(COALESCE(TRY_CAST(RETAIL_DISC AS DECIMAL(18,2)), 0))
# MAGIC     + ABS(COALESCE(TRY_CAST(COUPON_DISC AS DECIMAL(18,2)), 0))
# MAGIC     + ABS(COALESCE(TRY_CAST(COUPON_MATCH_DISC AS DECIMAL(18,2)), 0))
# MAGIC     AS DECIMAL(18,2)
# MAGIC   ) AS GrossSalesAmount
# MAGIC FROM retail_marketing.demo_bronze.transaction_data_raw
# MAGIC WHERE TRY_CAST(BASKET_ID AS BIGINT) IS NOT NULL
# MAGIC   AND TRY_CAST(PRODUCT_ID AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.product_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(PRODUCT_ID AS INT) AS ProductID,
# MAGIC   CAST(MANUFACTURER AS INT) AS ManufacturerID,
# MAGIC   TRIM(DEPARTMENT) AS Department,
# MAGIC   TRIM(BRAND) AS Brand,
# MAGIC   TRIM(COMMODITY_DESC) AS CommodityDescription,
# MAGIC   TRIM(SUB_COMMODITY_DESC) AS SubCommodityDescription,
# MAGIC   TRIM(CURR_SIZE_OF_PRODUCT) AS CurrentProductSize
# MAGIC FROM retail_marketing.demo_bronze.product_raw
# MAGIC WHERE TRY_CAST(PRODUCT_ID AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.household_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(household_key AS INT) AS HouseholdID,
# MAGIC   TRIM(AGE_DESC) AS AgeDescription,
# MAGIC   TRIM(MARITAL_STATUS_CODE) AS MaritalStatus,
# MAGIC   TRIM(INCOME_DESC) AS IncomeDescription,
# MAGIC   TRIM(HOMEOWNER_DESC) AS HomeownerDescription,
# MAGIC   TRIM(HH_COMP_DESC) AS HouseholdComposition,
# MAGIC   TRIM(HOUSEHOLD_SIZE_DESC) AS HouseholdSize,
# MAGIC   TRIM(KID_CATEGORY_DESC) AS KidCategory
# MAGIC FROM retail_marketing.demo_bronze.household_demographic_raw
# MAGIC WHERE TRY_CAST(household_key AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.campaign_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(CAMPAIGN AS INT) AS CampaignID,
# MAGIC   TRIM(DESCRIPTION) AS CampaignDescription,
# MAGIC   CAST(START_DAY AS INT) AS StartDay,
# MAGIC   CAST(END_DAY AS INT) AS EndDay,
# MAGIC   CAST(END_DAY AS INT) - CAST(START_DAY AS INT) + 1 AS CampaignDuration
# MAGIC FROM retail_marketing.demo_bronze.campaign_desc_raw
# MAGIC WHERE TRY_CAST(CAMPAIGN AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.campaign_target_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(household_key AS INT) AS HouseholdID,
# MAGIC   CAST(CAMPAIGN AS INT) AS CampaignID,
# MAGIC   TRIM(DESCRIPTION) AS CampaignDescription
# MAGIC FROM retail_marketing.demo_bronze.campaign_target_raw
# MAGIC WHERE TRY_CAST(household_key AS INT) IS NOT NULL
# MAGIC   AND TRY_CAST(CAMPAIGN AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.coupon_product_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(COUPON_UPC AS BIGINT) AS CouponUPC,
# MAGIC   CAST(PRODUCT_ID AS INT) AS ProductID,
# MAGIC   CAST(CAMPAIGN AS INT) AS CampaignID
# MAGIC FROM retail_marketing.demo_bronze.coupon_raw
# MAGIC WHERE TRY_CAST(COUPON_UPC AS BIGINT) IS NOT NULL
# MAGIC   AND TRY_CAST(PRODUCT_ID AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.coupon_redemption_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT DISTINCT
# MAGIC   CAST(household_key AS INT) AS HouseholdID,
# MAGIC   CAST(COUPON_UPC AS BIGINT) AS CouponUPC,
# MAGIC   CAST(CAMPAIGN AS INT) AS CampaignID,
# MAGIC   CAST(DAY AS INT) AS RedemptionDay
# MAGIC FROM retail_marketing.demo_bronze.coupon_redemption_raw
# MAGIC WHERE TRY_CAST(household_key AS INT) IS NOT NULL
# MAGIC   AND TRY_CAST(COUPON_UPC AS BIGINT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_silver.promotion_weekly_clean
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   CAST(PRODUCT_ID AS INT) AS ProductID,
# MAGIC   CAST(STORE_ID AS INT) AS StoreID,
# MAGIC   CAST(WEEK_NO AS INT) AS WeekNumber,
# MAGIC   TRIM(display) AS DisplayType,
# MAGIC   TRIM(mailer) AS MailerType
# MAGIC FROM retail_marketing.demo_bronze.causal_data_raw
# MAGIC WHERE TRY_CAST(PRODUCT_ID AS INT) IS NOT NULL
# MAGIC   AND TRY_CAST(STORE_ID AS INT) IS NOT NULL
# MAGIC   AND TRY_CAST(WEEK_NO AS INT) IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Gold — Dimension tabloları
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.dim_product
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY ProductID) AS ProductKey,
# MAGIC   ProductID,
# MAGIC   ManufacturerID,
# MAGIC   Department,
# MAGIC   Brand,
# MAGIC   CommodityDescription,
# MAGIC   SubCommodityDescription,
# MAGIC   CurrentProductSize
# MAGIC FROM retail_marketing.demo_silver.product_clean;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.dim_household
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY HouseholdID) AS HouseholdKey,
# MAGIC   HouseholdID,
# MAGIC   AgeDescription,
# MAGIC   MaritalStatus,
# MAGIC   IncomeDescription,
# MAGIC   HomeownerDescription,
# MAGIC   HouseholdComposition,
# MAGIC   HouseholdSize,
# MAGIC   KidCategory
# MAGIC FROM retail_marketing.demo_silver.household_clean;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.dim_campaign
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY CampaignID) AS CampaignKey,
# MAGIC   CampaignID,
# MAGIC   CampaignDescription,
# MAGIC   StartDay,
# MAGIC   EndDay,
# MAGIC   CampaignDuration
# MAGIC FROM retail_marketing.demo_silver.campaign_clean;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.dim_store
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY StoreID) AS StoreKey,
# MAGIC   StoreID
# MAGIC FROM (
# MAGIC   SELECT DISTINCT StoreID
# MAGIC   FROM retail_marketing.demo_silver.transaction_clean
# MAGIC   WHERE StoreID IS NOT NULL
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.dim_day
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY DayNumber) AS DayKey,
# MAGIC   DayNumber,
# MAGIC   CAST(FLOOR((DayNumber - 1) / 7) + 1 AS INT) AS WeekNumber
# MAGIC FROM (
# MAGIC   SELECT DISTINCT DayNumber
# MAGIC   FROM retail_marketing.demo_silver.transaction_clean
# MAGIC   WHERE DayNumber IS NOT NULL
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Gold — Fact tabloları
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.fact_sales
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   t.BasketID,
# MAGIC   COALESCE(dp.ProductKey, -1) AS ProductKey,
# MAGIC   COALESCE(dh.HouseholdKey, -1) AS HouseholdKey,
# MAGIC   COALESCE(ds.StoreKey, -1) AS StoreKey,
# MAGIC   COALESCE(dd.DayKey, -1) AS DayKey,
# MAGIC   t.ProductID,
# MAGIC   t.HouseholdID,
# MAGIC   t.StoreID,
# MAGIC   t.DayNumber,
# MAGIC   t.WeekNumber,
# MAGIC   t.TransactionTime,
# MAGIC   t.Quantity,
# MAGIC   t.GrossSalesAmount,
# MAGIC   t.TotalDiscountAmount,
# MAGIC   t.NetSalesAmount,
# MAGIC   t.RetailDiscount,
# MAGIC   t.CouponDiscount,
# MAGIC   t.CouponMatchDiscount
# MAGIC FROM retail_marketing.demo_silver.transaction_clean t
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_product dp
# MAGIC   ON dp.ProductID = t.ProductID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_household dh
# MAGIC   ON dh.HouseholdID = t.HouseholdID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_store ds
# MAGIC   ON ds.StoreID = t.StoreID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_day dd
# MAGIC   ON dd.DayNumber = t.DayNumber;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.fact_coupon_redemption
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   cr.HouseholdID,
# MAGIC   cr.CouponUPC,
# MAGIC   cr.CampaignID,
# MAGIC   cr.RedemptionDay,
# MAGIC   COALESCE(dh.HouseholdKey, -1) AS HouseholdKey,
# MAGIC   COALESCE(dc.CampaignKey, -1) AS CampaignKey
# MAGIC FROM retail_marketing.demo_silver.coupon_redemption_clean cr
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_household dh
# MAGIC   ON dh.HouseholdID = cr.HouseholdID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_campaign dc
# MAGIC   ON dc.CampaignID = cr.CampaignID;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.fact_campaign_target
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   ct.HouseholdID,
# MAGIC   ct.CampaignID,
# MAGIC   COALESCE(dh.HouseholdKey, -1) AS HouseholdKey,
# MAGIC   COALESCE(dc.CampaignKey, -1) AS CampaignKey
# MAGIC FROM retail_marketing.demo_silver.campaign_target_clean ct
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_household dh
# MAGIC   ON dh.HouseholdID = ct.HouseholdID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_campaign dc
# MAGIC   ON dc.CampaignID = ct.CampaignID;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_gold.fact_promotion_weekly
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   p.ProductID,
# MAGIC   p.StoreID,
# MAGIC   p.WeekNumber,
# MAGIC   p.DisplayType,
# MAGIC   p.MailerType,
# MAGIC   COALESCE(dp.ProductKey, -1) AS ProductKey,
# MAGIC   COALESCE(ds.StoreKey, -1) AS StoreKey
# MAGIC FROM retail_marketing.demo_silver.promotion_weekly_clean p
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_product dp
# MAGIC   ON dp.ProductID = p.ProductID
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_store ds
# MAGIC   ON ds.StoreID = p.StoreID;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Data Mart — Günlük satış
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_dm.dm_daily_sales
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   DayNumber,
# MAGIC   WeekNumber,
# MAGIC   COUNT(DISTINCT BasketID) AS BasketCount,
# MAGIC   COUNT(DISTINCT HouseholdID) AS HouseholdCount,
# MAGIC   COUNT(DISTINCT ProductID) AS ProductCount,
# MAGIC   COUNT(DISTINCT StoreID) AS StoreCount,
# MAGIC   SUM(Quantity) AS TotalQuantity,
# MAGIC   SUM(GrossSalesAmount) AS GrossSalesAmount,
# MAGIC   SUM(TotalDiscountAmount) AS TotalDiscountAmount,
# MAGIC   SUM(NetSalesAmount) AS NetSalesAmount,
# MAGIC   SUM(CASE WHEN COALESCE(CouponDiscount,0) <> 0 OR COALESCE(CouponMatchDiscount,0) <> 0 THEN 1 ELSE 0 END) AS CouponTransactionCount,
# MAGIC   SUM(NetSalesAmount) / NULLIF(COUNT(DISTINCT BasketID), 0) AS AverageBasketAmount,
# MAGIC   SUM(TotalDiscountAmount) / NULLIF(SUM(GrossSalesAmount), 0) AS DiscountRate,
# MAGIC   SUM(CASE WHEN COALESCE(CouponDiscount,0) <> 0 OR COALESCE(CouponMatchDiscount,0) <> 0 THEN 1 ELSE 0 END)
# MAGIC     / NULLIF(COUNT(*), 0) AS CouponTransactionRate
# MAGIC FROM retail_marketing.demo_gold.fact_sales
# MAGIC GROUP BY DayNumber, WeekNumber;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Data Mart — Ürün performansı
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_dm.dm_product_sales
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   fs.ProductID,
# MAGIC   dp.Department,
# MAGIC   dp.Brand,
# MAGIC   dp.CommodityDescription,
# MAGIC   COUNT(DISTINCT fs.BasketID) AS BasketCount,
# MAGIC   COUNT(DISTINCT fs.HouseholdID) AS HouseholdCount,
# MAGIC   COUNT(DISTINCT fs.StoreID) AS StoreCount,
# MAGIC   SUM(fs.Quantity) AS TotalQuantity,
# MAGIC   SUM(fs.GrossSalesAmount) AS GrossSalesAmount,
# MAGIC   SUM(fs.TotalDiscountAmount) AS TotalDiscountAmount,
# MAGIC   SUM(fs.NetSalesAmount) AS NetSalesAmount,
# MAGIC   SUM(CASE WHEN COALESCE(fs.CouponDiscount,0) <> 0 OR COALESCE(fs.CouponMatchDiscount,0) <> 0 THEN 1 ELSE 0 END) AS CouponTransactionCount,
# MAGIC   SUM(fs.NetSalesAmount) / NULLIF(SUM(fs.Quantity), 0) AS AverageUnitNetSales,
# MAGIC   SUM(fs.TotalDiscountAmount) / NULLIF(SUM(fs.GrossSalesAmount), 0) AS DiscountRate,
# MAGIC   SUM(CASE WHEN COALESCE(fs.CouponDiscount,0) <> 0 OR COALESCE(fs.CouponMatchDiscount,0) <> 0 THEN 1 ELSE 0 END)
# MAGIC     / NULLIF(COUNT(*), 0) AS CouponUsageRate,
# MAGIC   DENSE_RANK() OVER (ORDER BY SUM(fs.NetSalesAmount) DESC) AS NetSalesRank,
# MAGIC   DENSE_RANK() OVER (ORDER BY SUM(fs.Quantity) DESC) AS QuantityRank
# MAGIC FROM retail_marketing.demo_gold.fact_sales fs
# MAGIC LEFT JOIN retail_marketing.demo_gold.dim_product dp
# MAGIC   ON dp.ProductKey = fs.ProductKey
# MAGIC GROUP BY
# MAGIC   fs.ProductID,
# MAGIC   dp.Department,
# MAGIC   dp.Brand,
# MAGIC   dp.CommodityDescription;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Data Mart — Kampanya performansı
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_dm.dm_campaign_performance
# MAGIC USING DELTA
# MAGIC AS
# MAGIC WITH targets AS (
# MAGIC   SELECT
# MAGIC     CampaignID,
# MAGIC     COUNT(*) AS TargetHouseholdCount
# MAGIC   FROM retail_marketing.demo_gold.fact_campaign_target
# MAGIC   GROUP BY CampaignID
# MAGIC ),
# MAGIC redemptions AS (
# MAGIC   SELECT
# MAGIC     CampaignID,
# MAGIC     COUNT(*) AS RedemptionCount,
# MAGIC     COUNT(DISTINCT HouseholdID) AS RedeemingHouseholdCount,
# MAGIC     COUNT(DISTINCT CouponUPC) AS DistinctCouponCount
# MAGIC   FROM retail_marketing.demo_gold.fact_coupon_redemption
# MAGIC   GROUP BY CampaignID
# MAGIC )
# MAGIC SELECT
# MAGIC   dc.CampaignID,
# MAGIC   dc.CampaignDescription,
# MAGIC   dc.StartDay,
# MAGIC   dc.EndDay,
# MAGIC   dc.CampaignDuration,
# MAGIC   COALESCE(t.TargetHouseholdCount, 0) AS TargetHouseholdCount,
# MAGIC   COALESCE(r.RedeemingHouseholdCount, 0) AS RedeemingHouseholdCount,
# MAGIC   COALESCE(r.RedemptionCount, 0) AS RedemptionCount,
# MAGIC   COALESCE(r.DistinctCouponCount, 0) AS DistinctCouponCount,
# MAGIC   COALESCE(r.RedeemingHouseholdCount, 0) / NULLIF(COALESCE(t.TargetHouseholdCount, 0), 0) AS RedemptionRate,
# MAGIC   CASE
# MAGIC     WHEN COALESCE(r.RedeemingHouseholdCount, 0) / NULLIF(COALESCE(t.TargetHouseholdCount, 0), 0) >= 0.20 THEN 'HIGH'
# MAGIC     WHEN COALESCE(r.RedeemingHouseholdCount, 0) / NULLIF(COALESCE(t.TargetHouseholdCount, 0), 0) >= 0.10 THEN 'MEDIUM'
# MAGIC     ELSE 'LOW'
# MAGIC   END AS CampaignPerformanceLevel
# MAGIC FROM retail_marketing.demo_gold.dim_campaign dc
# MAGIC LEFT JOIN targets t
# MAGIC   ON t.CampaignID = dc.CampaignID
# MAGIC LEFT JOIN redemptions r
# MAGIC   ON r.CampaignID = dc.CampaignID;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Data Mart — Promotion performansı
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE retail_marketing.demo_dm.dm_promotion_performance
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC   fp.ProductID,
# MAGIC   fp.StoreID,
# MAGIC   fp.WeekNumber,
# MAGIC   CASE
# MAGIC     WHEN UPPER(COALESCE(fp.DisplayType,'')) NOT IN ('0','A','NONE','') 
# MAGIC       AND UPPER(COALESCE(fp.MailerType,'')) NOT IN ('0','A','NONE','') THEN 'DISPLAY_AND_MAILER'
# MAGIC     WHEN UPPER(COALESCE(fp.DisplayType,'')) NOT IN ('0','A','NONE','') THEN 'DISPLAY'
# MAGIC     WHEN UPPER(COALESCE(fp.MailerType,'')) NOT IN ('0','A','NONE','') THEN 'MAILER'
# MAGIC     ELSE 'NO_PROMOTION'
# MAGIC   END AS PromotionType,
# MAGIC   COUNT(*) AS PromotionCount,
# MAGIC   COUNT(DISTINCT fs.BasketID) AS BasketCount,
# MAGIC   SUM(COALESCE(fs.Quantity,0)) AS TotalQuantity,
# MAGIC   SUM(COALESCE(fs.GrossSalesAmount,0)) AS GrossSalesAmount,
# MAGIC   SUM(COALESCE(fs.TotalDiscountAmount,0)) AS TotalDiscountAmount,
# MAGIC   SUM(COALESCE(fs.NetSalesAmount,0)) AS NetSalesAmount,
# MAGIC   SUM(COALESCE(fs.NetSalesAmount,0)) / NULLIF(COUNT(DISTINCT fs.BasketID),0) AS AverageBasketAmount
# MAGIC FROM retail_marketing.demo_gold.fact_promotion_weekly fp
# MAGIC LEFT JOIN retail_marketing.demo_gold.fact_sales fs
# MAGIC   ON fs.ProductID = fp.ProductID
# MAGIC  AND fs.StoreID = fp.StoreID
# MAGIC  AND fs.WeekNumber = fp.WeekNumber
# MAGIC GROUP BY
# MAGIC   fp.ProductID,
# MAGIC   fp.StoreID,
# MAGIC   fp.WeekNumber,
# MAGIC   CASE
# MAGIC     WHEN UPPER(COALESCE(fp.DisplayType,'')) NOT IN ('0','A','NONE','') 
# MAGIC       AND UPPER(COALESCE(fp.MailerType,'')) NOT IN ('0','A','NONE','') THEN 'DISPLAY_AND_MAILER'
# MAGIC     WHEN UPPER(COALESCE(fp.DisplayType,'')) NOT IN ('0','A','NONE','') THEN 'DISPLAY'
# MAGIC     WHEN UPPER(COALESCE(fp.MailerType,'')) NOT IN ('0','A','NONE','') THEN 'MAILER'
# MAGIC     ELSE 'NO_PROMOTION'
# MAGIC   END;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Dashboard view'ları
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW retail_marketing.demo_dm.vw_daily_sales_kpi AS
# MAGIC SELECT *
# MAGIC FROM retail_marketing.demo_dm.dm_daily_sales;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW retail_marketing.demo_dm.vw_top_products AS
# MAGIC SELECT *
# MAGIC FROM retail_marketing.demo_dm.dm_product_sales
# MAGIC ORDER BY NetSalesRank;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW retail_marketing.demo_dm.vw_campaign_performance AS
# MAGIC SELECT *
# MAGIC FROM retail_marketing.demo_dm.dm_campaign_performance;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW retail_marketing.demo_dm.vw_promotion_performance AS
# MAGIC SELECT *
# MAGIC FROM retail_marketing.demo_dm.dm_promotion_performance;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. Kontrol
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 'BRONZE_TRANSACTION' AS ObjectName, COUNT(*) AS RowCount
# MAGIC FROM retail_marketing.demo_bronze.transaction_data_raw
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'SILVER_TRANSACTION', COUNT(*)
# MAGIC FROM retail_marketing.demo_silver.transaction_clean
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'GOLD_FACT_SALES', COUNT(*)
# MAGIC FROM retail_marketing.demo_gold.fact_sales
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'DM_DAILY_SALES', COUNT(*)
# MAGIC FROM retail_marketing.demo_dm.dm_daily_sales
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'DM_PRODUCT_SALES', COUNT(*)
# MAGIC FROM retail_marketing.demo_dm.dm_product_sales
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'DM_CAMPAIGN_PERFORMANCE', COUNT(*)
# MAGIC FROM retail_marketing.demo_dm.dm_campaign_performance
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'DM_PROMOTION_PERFORMANCE', COUNT(*)
# MAGIC FROM retail_marketing.demo_dm.dm_promotion_performance;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dashboard için kullanılacak kaynaklar
# MAGIC
# MAGIC ```sql
# MAGIC SELECT * FROM retail_marketing.demo_dm.vw_daily_sales_kpi;
# MAGIC SELECT * FROM retail_marketing.demo_dm.vw_top_products;
# MAGIC SELECT * FROM retail_marketing.demo_dm.vw_campaign_performance;
# MAGIC SELECT * FROM retail_marketing.demo_dm.vw_promotion_performance;
# MAGIC ```
# MAGIC
# MAGIC Bu notebook `CREATE OR REPLACE` kullandığı için tekrar çalıştırılabilir ve mevcut ana pipeline tablolarına dokunmaz.
# MAGIC